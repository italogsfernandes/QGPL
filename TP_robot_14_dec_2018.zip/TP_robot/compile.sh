g++ -c CDijkstra.h
g++ -c CDijkstra.cpp
g++ -c CRobot.h
g++ -c CRobot.cpp
g++ -c CTest.h
g++ -c CTest.cpp
g++ -c CObjet.h
g++ -c CObjet.cpp
g++ -c CSalle.h
g++ -c CSalle.cpp
g++ -c main.cpp
g++ -o main.exe main.o CDijkstra.o CRobot.o CSalle.o CObjet.o
