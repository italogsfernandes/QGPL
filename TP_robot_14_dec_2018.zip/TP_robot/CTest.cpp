/* ************************************************************************** */
/** CRobot Class Implementation
*  #Entreprise
*    UCBL1 - Polytech - QGPL
*  #Équipe
   LY Hélène
   RUIZ CANADA Paula
   SAMPAIO FERNANDES Italo Gustavo
   IRUMVA Bella

*  #Résumé
*    Identification de l'objet et sa position.
*  #Description

*/
/* ************************************************************************** */
//////////////
// Includes //
//////////////
#include "CTest.h"

/////////////////
// Constructor //
/////////////////
CTest::CTest(){
    ;
}

CTest::~CTest(){
    ;
}

////////////////////
// Public Methods //
////////////////////
int CTest::test_lire_carte_et_afficher(){
    CRobot example_robot;
    example_robot = CRobot();
    return 0;
}

int CTest::test_chercher_cinq_objets(){
    printf("TODO");
    return 0;
}

int CTest::test_chercher_object_en_contournant_un_obstacle(){
    printf("TODO");
    return 0;
}

int CTest::test_introduction_character_incorrect(){
    printf("TODO");
    return 0;
}

int CTest::lancer_tests(){
    printf("TODO");
    return 0;
}

int CTest::test_executer_programme_3min(){
    printf("TODO");
    return 0;
}

int CTest::test_meme_resultats(){
    printf("TODO");
    return 0;
}

/////////////////////
// Private Methods //
/////////////////////


/*******************************************************************************
 End of File
*/
