./compile.sh
./main.exe
