/* ************************************************************************** */
/** CRobot Class Implementation
 *  #Entreprise
 *    UCBL1 - Polytech - QGPL
 *  #Équipe
 *    John Doe1
 *    John Doe2
 *    John Doe3
 *    John Doe4
 *  #Création
 *    John Doe1 - Date
 *  #Nom de fichier
 *    CRobot.cpp
 *  #Résumé
 *    Lorem ipsum dolor sit amet, consectetur adipisicing elit.
 *  #Description
 *    Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
 *    tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim
 *    veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea
 *    commodo consequat. Duis aute irure dolor in reprehenderit in voluptate
 *    velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint
 *    occaecat cupidatat non proident, sunt in culpa qui officia deserunt
 *    mollit anim id est laborum.
 */
/* ************************************************************************** */
//////////////
// Includes //
//////////////
#include "CTest.h"

/////////////////
// Constructor //
/////////////////
CTest::CTest(){
    ;
}

CTest::~CTest(){
    ;
}

////////////////////
// Public Methods //
////////////////////
int CTest::test_lire_carte_et_afficher(){
    CRobot example_robot;
    example_robot = CRobot();
    return 0;
}

int CTest::test_chercher_cinq_objets(){
    printf("TODO");
    return 0;
}

int CTest::test_chercher_object_en_contournant_un_obstacle(){
    printf("TODO");
    return 0;
}

int CTest::test_introduction_character_incorrect(){
    printf("TODO");
    return 0;
}

int CTest::lancer_tests(){
    printf("TODO");
    return 0;
}

int CTest::test_executer_programme_3min(){
    printf("TODO");
    return 0;
}

int CTest::test_meme_resultats(){
    printf("TODO");
    return 0;
}

/////////////////////
// Private Methods //
/////////////////////


/*******************************************************************************
 End of File
*/
